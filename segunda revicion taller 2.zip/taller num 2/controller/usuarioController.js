const db =require("../confic/database")
   class UsuarioController {

       static async obtenerUsuario(req,res){
            let lista = await db.query("SELECT* FROM empresa ");
            res.json(lista);
        }
        static async insertarUsuario(req,res){
            let{nombre,email}=req.body;
            await db.query("INSERT INTO empresa(nombre, email ) VALUES(?,?)",[nombre,email]);
        }
        static async eliminarUsuario(req,res){
            let{id}=req=params
            await db.query("DELETE FROM empresa WHERE id=?",[id]);
        }
        static async actualizarUsuario(req,res){
            let{id}=req=params
            let{nombre,email}=req.body;
            await db.query("UPDATE empresa SET nombre=? WHERE id=?",[nombre, email, id]);
        }   
        static buscarEmpresa(){
            
        }
    }
    module.exports=UsuarioController;