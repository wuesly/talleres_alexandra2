const db =require("../confic/database")
   class PrestamoController {

       static async obtenerPrestamo(req,res){
            let lista = await db.query("SELECT* FROM empresa ");
            res.json(lista);
        }
        static async insertarPrestamo(req,res){
            let{nombre,email}=req.body;
            await db.query("INSERT INTO empresa(nombre, email ) VALUES(?,?)",[nombre,email]);
        }
        static async eliminarPrestamo(req,res){
            let{id}=req=params
            await db.query("DELETE FROM empresa WHERE id=?",[id]);
        }
        static async actualizarPrestamo(req,res){
            let{id}=req=params
            let{nombre,email}=req.body;
            await db.query("UPDATE empresa SET nombre=? WHERE id=?",[nombre, email, id]);
        }   
        static buscarEmpresa(){
            
        }
    }
    module.exports=PrestamoController;
    