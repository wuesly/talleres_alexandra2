const Mysql =require("Mysql2");
const pool= Mysql.createPool({
    host:"localhost",
    user:"root",
    password: "12345",
    database: "expressbiblioteca",
});
module.exports=pool.promise();