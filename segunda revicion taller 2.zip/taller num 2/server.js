const express = require('express');
const app = express();
app.use(express.json());


const libroRouter = require('./router/libroRouter');
app.use("/api",libroRouter);


const PORT = 3130;
app.listen(PORT,()=> {
    console.log(`el servidor esta CORRIENDO EN EL PUERTO: ${PORT}`);
}); 