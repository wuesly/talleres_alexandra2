const db =require("../confic/database")
   class LibroController {
    
    static async obtenerLibros(req,res){
        let [lista] = await db.query("SELECT* FROM empleado ");
        res.json(lista);
    }
    static async insertarLibros(req,res){
        let{nombre,apellido,email}=req.body;
        let empleado=await db.query("INSERT INTO empleado(nombre,apellido,email) VALUES(?,?,?)",[nombre,apellido,email]);
        res.json(req.body);
    }
    static async eliminarLibros(req,res){
        let{id}=req.params
        await db.query("DELETE FROM empleado WHERE id=?",[id]);
        res.send({mensaje:"registro eliminado"});
    }
    static async actualizarLibros(req,res){
        let{id}=req=params
        let{nombre,apellido,email}=req.body;
        await db.query("UPDATE empleado SET nombre=?,apellido=?,emaill=? WHERE id=?",[nombre,apellido,email,id]);
        res.json(req.body)
    }   
    static async obtenerLibros(req,res){
        let{buscarN}=req=params
        let buscar= await db.query("select * from empleado where nombre=?",[buscarN]);
        res.json(buscar);
    }
}
module.exports=LibroController;