const express = require('express');
const router = express.Router()
const PrestamoController=require("../controller/prestamoController")

router.get ("/prestamo", PrestamoController.obtenerPrestamo);
router.post ("/prestamo", PrestamoController.insertarPrestamo);   
router.delete ("/prestamo", PrestamoController.eliminarPrestamo);  
router.put ("/prestamo", PrestamoController.actualizarPrestamo);  
module.exports=router;