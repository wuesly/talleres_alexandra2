const express = require('express');
const router = express.Router()
const UsuarioController=require("../controller/usuarioController")

router.get ("/usuario", UsuarioController.obtenerUsuario);
router.post ("/usuario", UsuarioController.insertarUsuario);   
router.delete ("/usuario", UsuarioController.eliminarUsuario);  
router.put ("/usuario", UsuarioController.actualizarUsuario);  
module.exports=router;